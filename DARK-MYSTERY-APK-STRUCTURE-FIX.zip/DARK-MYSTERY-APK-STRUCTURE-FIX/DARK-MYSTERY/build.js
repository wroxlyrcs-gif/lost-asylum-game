const fs = require("fs");
const path = require("path");
const root = __dirname;
const out = path.join(root, "www");

for (const item of ["index.html", "css", "js"]) {
  if (!fs.existsSync(path.join(root, item))) {
    throw new Error(`Missing required project item: ${item}`);
  }
}

fs.rmSync(out, { recursive: true, force: true });
fs.mkdirSync(out, { recursive: true });
for (const item of ["index.html", "css", "js", "assets"]) {
  const from = path.join(root, item);
  if (fs.existsSync(from)) {
    fs.cpSync(from, path.join(out, item), { recursive: true });
  }
}
console.log("Prepared Capacitor webDir: www/");
